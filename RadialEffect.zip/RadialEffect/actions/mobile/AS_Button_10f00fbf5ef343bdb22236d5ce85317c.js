function AS_Button_10f00fbf5ef343bdb22236d5ce85317c(eventobject) {
    return radialEffect.call(this);
}